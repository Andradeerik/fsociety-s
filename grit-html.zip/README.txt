# grit-html
HTML version of Grit
Designed by Dcrazed.com
https://dcrazed.com/grit-creative-website-template/ 

#License
Free for using on your website and client projects. 
Please don't sell this template. Why? Its free. Share it.

#WordPress
Need WordPress version? Look out for it in 
https://dcrazed.com/themes/